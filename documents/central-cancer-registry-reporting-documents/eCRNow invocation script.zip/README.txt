###########################################################################################
Example python script to call the HDEA receive-notification endpoint with the JSON payload. 
The call will start the HCS survey report query and submission
###########################################################################################

The script must be called with 4 arguments.
###########################################################################################
First Arg = EHR FHIR Service URL - must match with a configuration entry from Healthcare setting in HDEA
E.g: https://nchs-test-service-fhir/base

###########################################################################################
Second Arg = CSV delimted file containing the encounter and patient IDs. First column is the encounterId and the second column is the patientID
The file patient-enc-test-data.csv is a test sample data file.

###########################################################################################
Third Arg = JSON Payload template file. This is the payload file that will be updated with the patient and encounter id for each call.
File sub-event-template.json is the template filed used by the script

###########################################################################################
Fourth Arg = The HDEA server URL and port. 
E.g: http://localhost:8081

###########################################################################################
Example to run the script:
python.exe call_notification_example.py https://nchs-test-service-fhir/base patient-enc-test-data.csv sub-event-template.json http://localhost:8081

